#include <iostream>
using namespace std;
#include <cstdio>
#include "estudiante.h"
#include "examen.h"

int main()
{
    listar_estudiantes();
    return 0;
}
